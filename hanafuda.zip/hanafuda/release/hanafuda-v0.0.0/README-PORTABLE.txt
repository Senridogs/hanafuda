Hanafuda Portable Package (0.0.0)

使い方:
1. このフォルダ全体を他PCへコピーします
2. まずは hanafuda-standalone.html をブラウザで開きます（推奨）
3. もし開けない場合は、同梱のローカルサーバースクリプトを実行します
   - macOS / Linux: ./start-local-server.sh
   - Windows(推奨): web フォルダで PowerShell を開き、py -3 -m http.server 4173 を実行
   - Windows(代替): start-local-server.bat (SmartScreen で警告される場合があります)
4. ブラウザで http://localhost:4173 を開きます

補足:
- Node.js は不要です
- 札画像は Wikimedia Commons から取得するため、インターネット接続は必要です
