#!/usr/bin/env bash
set -eu
SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$SCRIPT_DIR/web"
if command -v python3 >/dev/null 2>&1; then
  python3 -m http.server 4173
elif command -v python >/dev/null 2>&1; then
  python -m http.server 4173
else
  echo "Python が見つかりません。Python 3 をインストールしてください。"
  exit 1
fi
